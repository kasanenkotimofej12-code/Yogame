package com.jarvis.ai

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.*
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.core.graphics.drawable.toBitmap
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

val Bg = Color(0xFF05080F)
val Cyan = Color(0xFF00E5FF)
val Blue = Color(0xFF2979FF)

class MainActivity : ComponentActivity() {
    private lateinit var jarvis: Jarvis
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        jarvis = Jarvis(applicationContext)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme(primary = Cyan, background = Bg, surface = Bg)) {
                Surface(Modifier.fillMaxSize(), color = Bg) { Root(jarvis) }
            }
        }
    }
    override fun onDestroy() { jarvis.shutdown(); super.onDestroy() }
}

@Composable
fun Root(j: Jarvis) {
    var tab by remember { mutableIntStateOf(0) }
    val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        j.permRequest = null; j.retryPending()
    }
    LaunchedEffect(j.permRequest) { j.permRequest?.let { permLauncher.launch(it.toTypedArray()) } }
    Column(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding()) {
        Box(Modifier.weight(1f)) {
            when (tab) {
                0 -> Home(j)
                1 -> Apps(j)
                else -> SettingsScreen(j)
            }
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
            listOf("Главная", "Приложения", "Настройки").forEachIndexed { i, t ->
                TextButton(onClick = { tab = i }) {
                    Text(t, color = if (tab == i) Cyan else Color.Gray)
                }
            }
        }
    }
}

@Composable
fun Home(j: Jarvis) {
    val ctx = LocalContext.current
    var now by remember { mutableStateOf(Date()) }
    LaunchedEffect(Unit) { while (true) { now = Date(); delay(1000) } }
    var typed by remember { mutableStateOf("") }

    val perm = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        if (ok) j.startListening() else j.status = "Нужен доступ к микрофону"
    }
    fun mic() {
        if (j.listening) { j.stopListening(); return }
        if (ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED)
            j.startListening() else perm.launch(Manifest.permission.RECORD_AUDIO)
    }

    Column(Modifier.fillMaxSize().padding(16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Text(SimpleDateFormat("HH:mm", Locale("ru")).format(now), color = Cyan, fontSize = 56.sp, fontWeight = androidx.compose.ui.text.font.FontWeight.Light)
        Text(SimpleDateFormat("EEEE, d MMMM", Locale("ru")).format(now), color = Color.Gray)
        Spacer(Modifier.weight(1f))
        Box(Modifier.clip(CircleShape).clickable { mic() }) { Core(j.level, j.listening) }
        Text(j.name.uppercase(), color = Cyan, fontSize = 20.sp, letterSpacing = 6.sp)
        Spacer(Modifier.height(8.dp))
        Text("Обращайся: «${j.name}, открой ютуб»", color = Color.Gray, fontSize = 12.sp)
        Text(j.status, color = Color(0xFF9FD8E6), textAlign = TextAlign.Center, maxLines = 3)
        Spacer(Modifier.weight(1f))
        j.log.takeLast(4).forEach { Text(it, color = Color.Gray, fontSize = 12.sp, maxLines = 1) }
        Spacer(Modifier.height(8.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(typed, { typed = it }, Modifier.weight(1f), singleLine = true,
                placeholder = { Text("Команда текстом…") })
            Spacer(Modifier.width(8.dp))
            Button(onClick = { j.handle(typed); typed = "" }) { Text("OK") }
        }
        Spacer(Modifier.height(8.dp))
        Button(onClick = { mic() }, colors = ButtonDefaults.buttonColors(containerColor = if (j.listening) Blue else Cyan, contentColor = Bg)) {
            Text(if (j.listening) "Остановить" else "Говорить")
        }
    }
}

@Composable
fun Core(level: Float, listening: Boolean) {
    val t = rememberInfiniteTransition(label = "core")
    val rot by t.animateFloat(0f, 360f, infiniteRepeatable(tween(12000, easing = LinearEasing)), label = "r1")
    val rot2 by t.animateFloat(360f, 0f, infiniteRepeatable(tween(7000, easing = LinearEasing)), label = "r2")
    val pulse by t.animateFloat(0.92f, 1.06f, infiniteRepeatable(tween(1800, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "p")
    val lv by animateFloatAsState(if (listening) level else 0f, label = "lv")
    Canvas(Modifier.size(260.dp)) {
        val c = center; val r = size.minDimension / 2
        drawCircle(Brush.radialGradient(listOf(Cyan.copy(alpha = 0.55f), Color.Transparent), c, r * (0.7f + 0.3f * lv) * pulse), r)
        drawCircle(Cyan.copy(alpha = 0.9f), r * 0.26f * (1f + lv * 0.5f) * pulse, c)
        drawCircle(Bg, r * 0.18f * (1f + lv * 0.5f) * pulse, c)
        drawCircle(Cyan, r * 0.08f, c)
        for (i in 0 until 4) {
            drawArc(Cyan, rot + i * 90f, 55f, false, Offset(c.x - r * 0.9f, c.y - r * 0.9f), Size(r * 1.8f, r * 1.8f), style = Stroke(5f, cap = StrokeCap.Round))
            drawArc(Blue, rot2 + i * 90f + 30f, 40f, false, Offset(c.x - r * 0.72f, c.y - r * 0.72f), Size(r * 1.44f, r * 1.44f), style = Stroke(4f, cap = StrokeCap.Round))
        }
        for (i in 0 until 60) {
            val a = Math.toRadians(i * 6.0 + rot2 * 0.2)
            val len = if (i % 5 == 0) 14f else 6f
            val r1 = r * 0.55f; val r2 = r1 + len
            drawLine(Cyan.copy(alpha = 0.5f), Offset(c.x + (r1 * Math.cos(a)).toFloat(), c.y + (r1 * Math.sin(a)).toFloat()),
                Offset(c.x + (r2 * Math.cos(a)).toFloat(), c.y + (r2 * Math.sin(a)).toFloat()), 2f)
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun Apps(j: Jarvis) {
    var apps by remember { mutableStateOf(emptyList<AppInfo>()) }
    LaunchedEffect(Unit) { apps = j.installedApps() }
    var q by remember { mutableStateOf("") }
    val pm = LocalContext.current.packageManager
    val shown = apps.filter { it.label.contains(q, true) }
        .sortedByDescending { it.pkg in j.favorites }
    Column(Modifier.fillMaxSize().padding(12.dp)) {
        OutlinedTextField(q, { q = it }, Modifier.fillMaxWidth(), singleLine = true, placeholder = { Text("Поиск приложений") })
        Text("Долгое нажатие — в избранное", color = Color.Gray, fontSize = 11.sp, modifier = Modifier.padding(vertical = 4.dp))
        LazyVerticalGrid(GridCells.Fixed(4), Modifier.fillMaxSize()) {
            items(shown, key = { it.pkg }) { a ->
                val icon = remember(a.pkg) { runCatching { pm.getApplicationIcon(a.pkg).toBitmap(96, 96).asImageBitmap() }.getOrNull() }
                Column(Modifier.padding(4.dp).combinedClickable(onClick = { j.launch(a.pkg) }, onLongClick = { j.toggleFavorite(a.pkg) }),
                    horizontalAlignment = Alignment.CenterHorizontally) {
                    icon?.let { Image(it, null, Modifier.size(52.dp)) }
                    Text((if (a.pkg in j.favorites) "★ " else "") + a.label, color = Color.White, fontSize = 11.sp, maxLines = 1, textAlign = TextAlign.Center)
                }
            }
        }
    }
}

@Composable
fun SettingsScreen(j: Jarvis) {
    val ctx = LocalContext.current
    var n by remember { mutableStateOf(j.name) }
    val micOk = ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
    val perm = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {}
    Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Настройки", color = Cyan, fontSize = 22.sp)
        OutlinedTextField(n, { n = it }, Modifier.fillMaxWidth(), singleLine = true, label = { Text("Имя помощника") })
        Button(onClick = { j.saveName(n) }) { Text("Сохранить имя") }
        Text("Микрофон: " + if (micOk) "разрешён" else "не разрешён", color = Color.White)
        if (!micOk) Button(onClick = { perm.launch(Manifest.permission.RECORD_AUDIO) }) { Text("Дать доступ к микрофону") }
        Text("Зачем: только чтобы слышать команды после нажатия на кнопку.", color = Color.Gray, fontSize = 12.sp)
        Button(onClick = { ctx.startActivity(Intent(Settings.ACTION_HOME_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }) {
            Text("Сделать лаунчером по умолчанию")
        }
        Text("Голосовые команды выполняются только если в них есть имя: «${j.name}, позвони маме». Если имя распознаётся иначе, впиши его так, как оно появляется в журнале («Услышал: ...»). Не реализовано: постоянное прослушивание без нажатия, погода, виджеты, создание приложений (нужен ИИ).",
            color = Color.Gray, fontSize = 12.sp)
    }
}
