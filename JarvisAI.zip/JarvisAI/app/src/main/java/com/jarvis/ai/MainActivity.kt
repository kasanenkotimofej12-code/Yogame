package com.jarvis.ai

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.core.graphics.drawable.toBitmap
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

val Bg = Color(0xFF05080F)
val Cyan = Color(0xFF00E5FF)
val Blue = Color(0xFF2979FF)

object UiTick { var value by mutableIntStateOf(0) }

fun granted(c: Context, p: String) = ContextCompat.checkSelfPermission(c, p) == PackageManager.PERMISSION_GRANTED

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val jarvis = JarvisHolder.get(applicationContext)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme(primary = Cyan, background = Bg, surface = Bg)) {
                Surface(Modifier.fillMaxSize(), color = Bg) { Root(jarvis) }
            }
        }
    }
    override fun onResume() { super.onResume(); UiTick.value++ }
}

@Composable
fun Root(j: Jarvis) {
    var tab by remember { mutableIntStateOf(0) }
    val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        j.permRequest = null; j.retryPending()
    }
    LaunchedEffect(j.permRequest) { j.permRequest?.let { permLauncher.launch(it.toTypedArray()) } }

    Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xFF020409), Color(0xFF08182C), Color(0xFF020409))))) {
        Column(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding()) {
            TopBar(j)
            Box(Modifier.weight(1f)) {
                when (tab) {
                    0 -> Home(j)
                    1 -> Apps(j)
                    else -> SettingsScreen(j)
                }
            }
            NavBar(tab) { tab = it }
        }
    }
}

@Composable
fun TopBar(j: Jarvis) {
    Row(Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
        Text("J.A.R.V.I.S", color = Cyan, fontSize = 16.sp, letterSpacing = 4.sp, fontWeight = FontWeight.Medium)
        Spacer(Modifier.weight(1f))
        Box(Modifier.size(8.dp).clip(CircleShape).background(if (j.continuous) Color(0xFF00E676) else Color(0xFF607080)))
        Spacer(Modifier.width(6.dp))
        Text(if (j.continuous) "В ФОНЕ" else "ВЫКЛ", color = Color.Gray, fontSize = 11.sp, letterSpacing = 2.sp)
    }
}

@Composable
fun NavBar(selected: Int, onSelect: (Int) -> Unit) {
    val shape = RoundedCornerShape(30.dp)
    Row(
        Modifier.padding(horizontal = 20.dp, vertical = 10.dp).fillMaxWidth().clip(shape)
            .background(Color(0x1A00E5FF))
            .border(1.dp, Brush.horizontalGradient(listOf(Cyan.copy(alpha = 0.6f), Blue.copy(alpha = 0.6f))), shape)
            .padding(6.dp),
        horizontalArrangement = Arrangement.SpaceEvenly
    ) {
        listOf("Главная", "Приложения", "Настройки").forEachIndexed { i, label ->
            val sel = selected == i
            val col = if (sel) Cyan else Color(0xFF7C8A99)
            Column(
                Modifier.weight(1f).clip(RoundedCornerShape(24.dp))
                    .background(if (sel) Cyan.copy(alpha = 0.16f) else Color.Transparent)
                    .clickable { onSelect(i) }.padding(vertical = 8.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                NavIcon(i, col)
                Text(label, color = col, fontSize = 11.sp)
            }
        }
    }
}

@Composable
fun NavIcon(kind: Int, color: Color) {
    Canvas(Modifier.size(24.dp)) {
        val w = size.width
        when (kind) {
            0 -> { drawCircle(color, w / 2 - 2f, style = Stroke(3f)); drawCircle(color, 4f) }
            1 -> {
                val s = w / 2.5f; val gap = w - 2 * s
                for (x in 0..1) for (y in 0..1)
                    drawRoundRect(color, Offset(x * (s + gap), y * (s + gap)), Size(s, s), CornerRadius(3f))
            }
            else -> for (k in 0..2) {
                val y = size.height * (0.2f + 0.3f * k)
                drawLine(color, Offset(0f, y), Offset(w, y), 3f, StrokeCap.Round)
                drawCircle(color, 4.5f, Offset(w * (0.3f + 0.2f * k), y))
            }
        }
    }
}

@Composable
fun Home(j: Jarvis) {
    val ctx = LocalContext.current
    var now by remember { mutableStateOf(Date()) }
    LaunchedEffect(Unit) { while (true) { now = Date(); delay(1000) } }
    var typed by remember { mutableStateOf("") }
    var showOverlay by remember { mutableStateOf(false) }

    fun startSvc() { ContextCompat.startForegroundService(ctx, Intent(ctx, JarvisService::class.java)) }
    fun proceed() { if (Settings.canDrawOverlays(ctx)) startSvc() else showOverlay = true }

    val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        if (granted(ctx, Manifest.permission.RECORD_AUDIO)) proceed() else j.status = "Нужен доступ к микрофону"
    }
    val micLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        if (ok) j.startListening() else j.status = "Нужен доступ к микрофону"
    }

    fun toggle() {
        if (j.continuous) { ctx.stopService(Intent(ctx, JarvisService::class.java)); return }
        val need = mutableListOf<String>()
        if (!granted(ctx, Manifest.permission.RECORD_AUDIO)) need.add(Manifest.permission.RECORD_AUDIO)
        if (Build.VERSION.SDK_INT >= 33 && !granted(ctx, Manifest.permission.POST_NOTIFICATIONS)) need.add(Manifest.permission.POST_NOTIFICATIONS)
        if (need.isNotEmpty()) permLauncher.launch(need.toTypedArray()) else proceed()
    }
    fun mic() {
        if (j.continuous) return
        if (j.listening) { j.stopListening(); return }
        if (granted(ctx, Manifest.permission.RECORD_AUDIO)) j.startListening() else micLauncher.launch(Manifest.permission.RECORD_AUDIO)
    }

    if (showOverlay) {
        AlertDialog(
            onDismissRequest = { showOverlay = false },
            title = { Text("Нужно разрешение «Поверх других приложений»") },
            text = { Text("Без него Android не даёт открывать приложения, пока ты находишься в другом приложении (например, в WhatsApp). Включи переключатель для JARVIS AI, вернись и нажми кнопку ещё раз.") },
            confirmButton = {
                TextButton(onClick = {
                    showOverlay = false
                    ctx.startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + ctx.packageName)))
                }) { Text("Открыть настройки") }
            },
            dismissButton = { TextButton(onClick = { showOverlay = false; startSvc() }) { Text("Пропустить") } }
        )
    }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 20.dp),
        horizontalAlignment = Alignment.CenterHorizontally) {
        Text(SimpleDateFormat("HH:mm", Locale("ru")).format(now), color = Cyan, fontSize = 52.sp, fontWeight = FontWeight.Light)
        Text(SimpleDateFormat("EEEE, d MMMM", Locale("ru")).format(now), color = Color.Gray)
        Spacer(Modifier.height(12.dp))
        Box(Modifier.clip(CircleShape).clickable { mic() }) { Core(j.level, j.listening, 230.dp) }
        Text(j.name.uppercase(), color = Cyan, fontSize = 20.sp, letterSpacing = 6.sp)
        Spacer(Modifier.height(6.dp))
        Text(j.status, color = Color(0xFF9FD8E6), textAlign = TextAlign.Center, maxLines = 3)
        j.pendingSend?.let { ps ->
            Column(Modifier.fillMaxWidth().padding(top = 8.dp).clip(RoundedCornerShape(16.dp)).background(Color(0x2200E5FF))
                .border(1.dp, Cyan.copy(alpha = 0.5f), RoundedCornerShape(16.dp)).padding(12.dp)) {
                Text("Отправить ${ps.who} в WhatsApp:", color = Color.Gray, fontSize = 12.sp)
                Text(ps.text, color = Color.White)
                Row(Modifier.padding(top = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = { j.confirmSend() }) { Text("Отправить") }
                    OutlinedButton(onClick = { j.cancelSend() }) { Text("Отмена") }
                }
            }
        }
        Spacer(Modifier.height(16.dp))
        val on = j.continuous
        Button(
            onClick = { toggle() }, Modifier.fillMaxWidth().height(60.dp), shape = RoundedCornerShape(30.dp),
            colors = ButtonDefaults.buttonColors(containerColor = if (on) Color(0xFFFF5252) else Cyan, contentColor = Bg)
        ) { Text(if (on) "ВЫКЛЮЧИТЬ ПОМОЩНИКА" else "ВКЛЮЧИТЬ ПОМОЩНИКА", fontWeight = FontWeight.Bold, letterSpacing = 1.sp) }
        Text(
            if (on) "Слушаю в фоне. Скажи: «${j.name}, открой WhatsApp»" else "Нажми, и я буду слушать даже в других приложениях",
            color = Color.Gray, fontSize = 12.sp, textAlign = TextAlign.Center, modifier = Modifier.padding(top = 8.dp)
        )
        Spacer(Modifier.height(12.dp))
        j.log.takeLast(3).forEach { Text(it, color = Color.Gray, fontSize = 12.sp, maxLines = 1) }
        Spacer(Modifier.height(8.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(typed, { typed = it }, Modifier.weight(1f), singleLine = true,
                shape = RoundedCornerShape(20.dp), placeholder = { Text("Команда текстом…") })
            Spacer(Modifier.width(8.dp))
            Button(onClick = { j.handle(typed); typed = "" }) { Text("OK") }
        }
        Spacer(Modifier.height(12.dp))
    }
}

@Composable
fun Core(level: Float, listening: Boolean, size: Dp = 260.dp) {
    val t = rememberInfiniteTransition(label = "core")
    val rot by t.animateFloat(0f, 360f, infiniteRepeatable(tween(12000, easing = LinearEasing)), label = "r1")
    val rot2 by t.animateFloat(360f, 0f, infiniteRepeatable(tween(7000, easing = LinearEasing)), label = "r2")
    val pulse by t.animateFloat(0.92f, 1.06f, infiniteRepeatable(tween(1800, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "p")
    val lv by animateFloatAsState(if (listening) level else 0f, label = "lv")
    Canvas(Modifier.size(size)) {
        val c = center; val r = this.size.minDimension / 2
        drawCircle(Brush.radialGradient(listOf(Cyan.copy(alpha = 0.55f), Color.Transparent), c, r * (0.7f + 0.3f * lv) * pulse), r)
        drawCircle(Cyan.copy(alpha = 0.9f), r * 0.26f * (1f + lv * 0.5f) * pulse, c)
        drawCircle(Bg, r * 0.18f * (1f + lv * 0.5f) * pulse, c)
        drawCircle(Cyan, r * 0.08f, c)
        for (i in 0 until 4) {
            drawArc(Cyan, rot + i * 90f, 55f, false, Offset(c.x - r * 0.9f, c.y - r * 0.9f), Size(r * 1.8f, r * 1.8f), style = Stroke(5f, cap = StrokeCap.Round))
            drawArc(Blue, rot2 + i * 90f + 30f, 40f, false, Offset(c.x - r * 0.72f, c.y - r * 0.72f), Size(r * 1.44f, r * 1.44f), style = Stroke(4f, cap = StrokeCap.Round))
        }
        for (i in 0 until 60) {
            val a = Math.toRadians(i * 6.0 + rot2 * 0.2)
            val len = if (i % 5 == 0) 14f else 6f
            val r1 = r * 0.55f; val r2 = r1 + len
            drawLine(Cyan.copy(alpha = 0.5f), Offset(c.x + (r1 * Math.cos(a)).toFloat(), c.y + (r1 * Math.sin(a)).toFloat()),
                Offset(c.x + (r2 * Math.cos(a)).toFloat(), c.y + (r2 * Math.sin(a)).toFloat()), 2f)
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun Apps(j: Jarvis) {
    var apps by remember { mutableStateOf(emptyList<AppInfo>()) }
    LaunchedEffect(Unit) { apps = j.installedApps() }
    var q by remember { mutableStateOf("") }
    val pm = LocalContext.current.packageManager
    val shown = apps.filter { it.label.contains(q, true) }.sortedByDescending { it.pkg in j.favorites }
    Column(Modifier.fillMaxSize().padding(horizontal = 16.dp)) {
        OutlinedTextField(q, { q = it }, Modifier.fillMaxWidth(), singleLine = true,
            shape = RoundedCornerShape(20.dp), placeholder = { Text("Поиск приложений") })
        Text("Долгое нажатие — в избранное", color = Color.Gray, fontSize = 11.sp, modifier = Modifier.padding(vertical = 4.dp))
        LazyVerticalGrid(GridCells.Fixed(4), Modifier.fillMaxSize()) {
            items(shown, key = { it.pkg }) { a ->
                val icon = remember(a.pkg) { runCatching { pm.getApplicationIcon(a.pkg).toBitmap(96, 96).asImageBitmap() }.getOrNull() }
                Column(Modifier.padding(4.dp).combinedClickable(onClick = { j.launch(a.pkg) }, onLongClick = { j.toggleFavorite(a.pkg) }),
                    horizontalAlignment = Alignment.CenterHorizontally) {
                    icon?.let { Image(it, null, Modifier.size(52.dp)) }
                    Text((if (a.pkg in j.favorites) "★ " else "") + a.label, color = Color.White, fontSize = 11.sp, maxLines = 1, textAlign = TextAlign.Center)
                }
            }
        }
    }
}

@Composable
fun PermCard(title: String, ok: Boolean, desc: String, action: String, onClick: () -> Unit) {
    val shape = RoundedCornerShape(16.dp)
    Column(Modifier.fillMaxWidth().clip(shape).background(Color(0x1100E5FF)).border(1.dp, Cyan.copy(alpha = 0.3f), shape).padding(14.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(10.dp).clip(CircleShape).background(if (ok) Color(0xFF00E676) else Color(0xFFFFAB00)))
            Spacer(Modifier.width(8.dp))
            Text(title, color = Color.White, fontWeight = FontWeight.Medium)
            Spacer(Modifier.weight(1f))
            Text(if (ok) "включено" else "выключено", color = Color.Gray, fontSize = 12.sp)
        }
        Text(desc, color = Color.Gray, fontSize = 12.sp, modifier = Modifier.padding(top = 6.dp))
        if (!ok) TextButton(onClick = onClick) { Text(action, color = Cyan) }
    }
}

@Composable
fun SettingsScreen(j: Jarvis) {
    val ctx = LocalContext.current
    val tick = UiTick.value
    var n by remember { mutableStateOf(j.name) }
    val micLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { UiTick.value++ }
    val notifLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { UiTick.value++ }
    fun open(i: Intent) { ctx.startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
    val pm = ctx.getSystemService(PowerManager::class.java)

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Настройки", color = Cyan, fontSize = 22.sp)
        OutlinedTextField(n, { n = it }, Modifier.fillMaxWidth(), singleLine = true, shape = RoundedCornerShape(16.dp), label = { Text("Имя помощника") })
        Button(onClick = { j.saveName(n) }) { Text("Сохранить имя") }
        VoiceCard(j)
        PermCard("Микрофон", granted(ctx, Manifest.permission.RECORD_AUDIO),
            "Нужен, чтобы слышать команды.", "Разрешить") { micLauncher.launch(Manifest.permission.RECORD_AUDIO) }
        PermCard("Уведомления", Build.VERSION.SDK_INT < 33 || granted(ctx, Manifest.permission.POST_NOTIFICATIONS),
            "Показывают, что микрофон слушает в фоне, и позволяют выключить его.", "Разрешить") {
            if (Build.VERSION.SDK_INT >= 33) notifLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
        PermCard("Поверх других приложений", Settings.canDrawOverlays(ctx),
            "Без этого Android не даёт открывать приложения из фона.", "Открыть настройки") {
            open(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + ctx.packageName)))
        }
        PermCard("Специальные возможности (назад, скриншот)", JarvisAccessibilityService.instance != null,
            "Нужны для команд «назад», «скриншот» и чтобы нажимать «Отправить» в WhatsApp. Доступ к экрану ограничен только WhatsApp. На Android 13+ для APK не из магазина сначала: Настройки телефона → Приложения → JARVIS AI → ⋮ → «Разрешить ограниченные настройки».",
            "Открыть настройки") { open(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        PermCard("Работа без ограничений батареи", pm.isIgnoringBatteryOptimizations(ctx.packageName),
            "Иначе телефон может усыпить помощника в фоне.", "Открыть настройки") {
            open(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
        }
        Button(onClick = { open(Intent(Settings.ACTION_HOME_SETTINGS)) }) { Text("Сделать лаунчером по умолчанию") }
        Text("Голосовые команды выполняются только если в них есть имя: «${j.name}, позвони маме». Если имя распознаётся иначе, впиши его так, как оно появляется в журнале.",
            color = Color.Gray, fontSize = 12.sp)
        Text("Важно: распознавание речи делает сервис Google на телефоне, он может отправлять звук на свои серверы. Пока включён фоновый режим, горит значок микрофона и уведомление.",
            color = Color.Gray, fontSize = 12.sp)
        Spacer(Modifier.height(12.dp))
    }
}

@Composable
fun VoiceCard(j: Jarvis) {
    val ctx = LocalContext.current
    val voices = remember(j.ttsReady, UiTick.value) { j.russianVoices() }
    val shape = RoundedCornerShape(16.dp)
    Column(Modifier.fillMaxWidth().clip(shape).background(Color(0x1100E5FF)).border(1.dp, Cyan.copy(alpha = 0.3f), shape).padding(14.dp)) {
        Text("Голос помощника", color = Color.White, fontWeight = FontWeight.Medium)
        Text("Android не сообщает, какой голос мужской, а какой женский. Выбери на слух. Тембр ниже звучит более мужским, выше более женским.",
            color = Color.Gray, fontSize = 12.sp, modifier = Modifier.padding(vertical = 6.dp))
        if (voices.isEmpty()) {
            Text("Русские голоса не найдены. Установи их в настройках синтеза речи (Google), кнопка ниже.", color = Color(0xFFFFAB00), fontSize = 12.sp)
        }
        voices.forEachIndexed { i, v ->
            Row(Modifier.fillMaxWidth().clickable { j.chooseVoice(v) }, verticalAlignment = Alignment.CenterVertically) {
                RadioButton(selected = v.name == j.voiceName, onClick = { j.chooseVoice(v) })
                Column {
                    Text("Голос ${i + 1}" + if (v.isNetworkConnectionRequired) " · онлайн" else "", color = Color.White, fontSize = 14.sp)
                    Text(v.name, color = Color.Gray, fontSize = 10.sp)
                }
            }
        }
        Text("Тембр: %.2f".format(j.pitch), color = Color.White, fontSize = 13.sp)
        Slider(j.pitch, { j.changePitch(it) }, valueRange = 0.5f..1.5f, onValueChangeFinished = { j.preview() })
        Text("Скорость: %.2f".format(j.rate), color = Color.White, fontSize = 13.sp)
        Slider(j.rate, { j.changeRate(it) }, valueRange = 0.5f..1.5f, onValueChangeFinished = { j.preview() })
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(onClick = { j.changePitch(0.75f); j.preview() }) { Text("Ниже") }
            OutlinedButton(onClick = { j.changePitch(1.15f); j.preview() }) { Text("Выше") }
            Button(onClick = { j.preview() }) { Text("Проверить") }
        }
        TextButton(onClick = {
            try { ctx.startActivity(Intent("com.android.settings.TTS_SETTINGS").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
            catch (e: Exception) { ctx.startActivity(Intent(Settings.ACTION_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
        }) { Text("Установить другие голоса", color = Cyan) }
    }
}
