package com.jarvis.ai

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.os.Handler
import android.os.Looper
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

// Системные кнопки (назад, домой, скриншот) и нажатие «Отправить» в WhatsApp после подтверждения пользователя.
// Доступ к содержимому окна ограничен пакетами WhatsApp (см. accessibility_config.xml).
class JarvisAccessibilityService : AccessibilityService() {
    companion object { var instance: JarvisAccessibilityService? = null }

    override fun onServiceConnected() { instance = this }
    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}
    override fun onUnbind(intent: Intent?): Boolean { instance = null; return super.onUnbind(intent) }

    fun clickSendWhatsApp(onResult: (Boolean) -> Unit) {
        val h = Handler(Looper.getMainLooper())
        var tries = 0
        val r = object : Runnable {
            override fun run() {
                if (trySend()) { onResult(true); return }
                if (++tries >= 20) { onResult(false); return }
                h.postDelayed(this, 500)
            }
        }
        h.postDelayed(r, 1500)
    }

    private fun trySend(): Boolean {
        val root = rootInActiveWindow ?: return false
        val pkg = root.packageName?.toString() ?: return false
        if (!pkg.startsWith("com.whatsapp")) return false
        root.findAccessibilityNodeInfosByViewId("$pkg:id/send")?.firstOrNull { n ->
            val d = n.contentDescription?.toString()?.lowercase() ?: ""
            !(d.contains("голос") || d.contains("voice") || d.contains("record") || d.contains("запис"))
        }?.let { if (click(it)) return true }
        for (t in listOf("Отправить", "Send")) {
            root.findAccessibilityNodeInfosByText(t)?.firstOrNull {
                (it.contentDescription ?: it.text)?.toString()?.trim().equals(t, true)
            }?.let { if (click(it)) return true }
        }
        return false
    }

    private fun click(n: AccessibilityNodeInfo): Boolean {
        var x: AccessibilityNodeInfo? = n
        while (x != null && !x.isClickable) x = x.parent
        return x?.performAction(AccessibilityNodeInfo.ACTION_CLICK) == true
    }
}
