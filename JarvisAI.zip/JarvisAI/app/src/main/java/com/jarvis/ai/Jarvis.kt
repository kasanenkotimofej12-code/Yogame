package com.jarvis.ai

import android.Manifest
import android.content.pm.PackageManager
import android.provider.ContactsContract
import androidx.core.content.ContextCompat
import android.content.Context
import android.content.Intent
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.Uri
import android.os.Bundle
import android.provider.AlarmClock
import android.provider.MediaStore
import android.provider.Settings
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.view.KeyEvent
import androidx.compose.runtime.*
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class AppInfo(val label: String, val pkg: String)

class Jarvis(private val app: Context) {
    private val prefs = app.getSharedPreferences("jarvis", Context.MODE_PRIVATE)
    private var tts: TextToSpeech? = null
    private var recognizer: SpeechRecognizer? = null
    private var torchOn = false

    var name by mutableStateOf(prefs.getString("name", "Джарвис") ?: "Джарвис")
    var status by mutableStateOf("Готов к работе")
    var level by mutableFloatStateOf(0f)
    var listening by mutableStateOf(false)
    val log = mutableStateListOf<String>()
    var favorites by mutableStateOf(prefs.getStringSet("fav", emptySet()) ?: emptySet())

    var permRequest by mutableStateOf<List<String>?>(null)
    private var pendingCmd: String? = null
    private var retrying = false

    init {
        tts = TextToSpeech(app) { if (it == TextToSpeech.SUCCESS) tts?.language = Locale("ru", "RU") }
    }

    fun saveName(n: String) {
        if (n.isBlank()) return
        name = n.trim(); prefs.edit().putString("name", name).apply()
        say("Теперь меня зовут $name.")
    }

    fun toggleFavorite(pkg: String) {
        favorites = if (pkg in favorites) favorites - pkg else favorites + pkg
        prefs.edit().putStringSet("fav", favorites).apply()
    }

    // ---------- Голос ----------
    fun startListening() {
        if (!SpeechRecognizer.isRecognitionAvailable(app)) { status = "Распознавание речи недоступно"; return }
        recognizer?.destroy()
        recognizer = SpeechRecognizer.createSpeechRecognizer(app).apply {
            setRecognitionListener(object : RecognitionListener {
                override fun onReadyForSpeech(p: Bundle?) {}
                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(rms: Float) { level = ((rms + 2f) / 12f).coerceIn(0f, 1f) }
                override fun onBufferReceived(b: ByteArray?) {}
                override fun onEndOfSpeech() { listening = false; level = 0f }
                override fun onError(e: Int) { listening = false; level = 0f; status = "Не расслышал, попробуй ещё раз" }
                override fun onResults(r: Bundle?) {
                    listening = false; level = 0f
                    r?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()?.let { handle(it, voice = true) }
                }
                override fun onPartialResults(r: Bundle?) {
                    r?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()?.let { status = "«$it»" }
                }
                override fun onEvent(t: Int, p: Bundle?) {}
            })
            startListening(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
                .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                .putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ru-RU")
                .putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true))
        }
        listening = true; status = "Слушаю…"
    }

    fun stopListening() { recognizer?.stopListening(); listening = false; level = 0f; status = "Микрофон выключен" }

    fun shutdown() { recognizer?.destroy(); tts?.shutdown() }

    fun say(text: String) {
        log.add("$name: $text"); status = text
        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "j")
    }

    // ---------- Команды ----------
    fun handle(raw: String, voice: Boolean = false) {
        val text = raw.trim(); if (text.isEmpty()) return
        var c = text.lowercase().replace("ё", "е")
        val n = name.lowercase().replace("ё", "е")
        if (voice) {
            if (n !in c) {
                log.add("Услышал: «$text» (без обращения, игнорирую)")
                status = "Начни с имени: «$name, ...». Услышал: «$text»"
                return
            }
        }
        log.add("Вы: $text")
        c = c.replace(n, "").trim(' ', ',', '.', '!', '?')
        val reply = try { execute(c) } catch (e: Exception) { "Не получилось: ${e.message}" }
        say(reply)
    }

    fun retryPending() {
        val c = pendingCmd ?: return
        pendingCmd = null; retrying = true
        val reply = try { execute(c) } catch (e: Exception) { "Не получилось: ${e.message}" }
        retrying = false
        say(reply)
    }

    private fun granted(p: String) = ContextCompat.checkSelfPermission(app, p) == PackageManager.PERMISSION_GRANTED

    private fun call(c: String): String {
        val missing = listOf(Manifest.permission.READ_CONTACTS, Manifest.permission.CALL_PHONE).filter { !granted(it) }
        if (missing.isNotEmpty() && !retrying) {
            pendingCmd = c; permRequest = missing
            return "Мне нужен доступ к контактам и звонкам. Подтверди в окне."
        }
        val stop = setOf("контакту", "мне", "пожалуйста", "номеру", "на", "номер")
        val q = c.replace(Regex("^.*?(позвони|набери|звони)"), "").trim()
            .split(Regex("\\s+")).filter { it.isNotEmpty() && it !in stop }.joinToString(" ")
        if (q.isEmpty()) return "Кому позвонить?"
        val digits = q.replace(Regex("[\\s\\-()]"), "")
        val number: String; val who: String
        if (digits.matches(Regex("\\+?\\d{3,}"))) { number = digits; who = digits }
        else {
            if (!granted(Manifest.permission.READ_CONTACTS)) return "Нет доступа к контактам."
            val found = findContacts(q)
            if (found.isEmpty()) return "Контакт «$q» не найден."
            val names = found.map { it.first }.distinct()
            if (names.size > 1) return "Нашёл несколько: ${names.take(4).joinToString(", ")}. Уточни."
            number = found[0].second; who = found[0].first
        }
        val action = if (granted(Manifest.permission.CALL_PHONE)) Intent.ACTION_CALL else Intent.ACTION_DIAL
        go(Intent(action, Uri.parse("tel:" + Uri.encode(number))))
        return "Звоню: $who"
    }

    private fun prefix(a: String, b: String): Int { var i = 0; while (i < a.length && i < b.length && a[i] == b[i]) i++; return i }

    private fun findContacts(q: String): List<Pair<String, String>> {
        val qw = q.lowercase().replace("ё", "е").split(" ").filter { it.isNotEmpty() }
        val scored = mutableListOf<Triple<Int, String, String>>()
        app.contentResolver.query(ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
            arrayOf(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME, ContactsContract.CommonDataKinds.Phone.NUMBER),
            null, null, null)?.use { cur ->
            while (cur.moveToNext()) {
                val nm = cur.getString(0) ?: continue
                val num = cur.getString(1) ?: continue
                val words = nm.lowercase().replace("ё", "е").split(" ").filter { it.isNotEmpty() }
                var score = 0
                for (w in words) for (x in qw) {
                    val p = prefix(w, x)
                    if (p >= 3 || (p >= 2 && p == w.length)) score += p
                }
                if (score > 0) scored.add(Triple(score, nm, num))
            }
        }
        val best = scored.maxOfOrNull { it.first } ?: return emptyList()
        return scored.filter { it.first == best }.map { it.second to it.third }
    }

    private fun execute(c: String): String = when {
        c.isBlank() -> "Слушаю."
        "создай приложение" in c || "сделай приложение" in c || "создай игру" in c ->
            "Создание приложений в этой версии не поддерживается: здесь нет ИИ."
        "помощь" in c || "умеешь" in c ->
            "Умею: позвонить контакту, открыть приложение, фонарик, таймер, заметки, камера, настройки, музыка, поиск в интернете, время."
        "позвони" in c || "набери" in c || c.startsWith("звони") -> call(c)
        "фонар" in c -> torch(!("выключ" in c || "погас" in c || "отключ" in c))
        "таймер" in c -> timer(c)
        "заметк" in c -> note(c)
        "камер" in c || "сфотографируй" in c -> { go(Intent(MediaStore.ACTION_IMAGE_CAPTURE)); "Открываю камеру." }
        "музык" in c || "пауз" in c || "следующ" in c || "предыдущ" in c || "дальше" in c -> media(c)
        "wi-fi" in c || "вай" in c -> { go(Intent(Settings.ACTION_WIFI_SETTINGS)); "Открываю настройки Wi-Fi." }
        "bluetooth" in c || "блютуз" in c -> { go(Intent(Settings.ACTION_BLUETOOTH_SETTINGS)); "Открываю Bluetooth." }
        "настройк" in c -> { go(Intent(Settings.ACTION_SETTINGS)); "Открываю настройки." }
        "котор" in c && "час" in c || "сколько времени" in c || "время" in c ->
            "Сейчас " + SimpleDateFormat("HH:mm", Locale("ru")).format(Date())
        "какое число" in c || "дата" in c || "какой день" in c ->
            "Сегодня " + SimpleDateFormat("d MMMM, EEEE", Locale("ru")).format(Date())
        c.startsWith("найди") || c.startsWith("поищи") || c.startsWith("загугли") || c.startsWith("поиск") -> search(c)
        "сайт" in c -> site(c)
        c.startsWith("открой") || c.startsWith("запусти") || c.startsWith("включи") || c.startsWith("открыть") -> openApp(c)
        else -> openAppOrNull(c) ?: "Не понял команду. Скажи «помощь», чтобы узнать, что я умею."
    }

    private fun go(i: Intent) { app.startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }

    private fun torch(on: Boolean): String {
        val cm = app.getSystemService(CameraManager::class.java)
        val id = cm.cameraIdList.firstOrNull {
            cm.getCameraCharacteristics(it).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
        } ?: return "Фонарик на этом устройстве не найден."
        cm.setTorchMode(id, on); torchOn = on
        return if (on) "Фонарик включён." else "Фонарик выключен."
    }

    private val words = mapOf("одну" to 1, "одна" to 1, "две" to 2, "два" to 2, "три" to 3, "четыре" to 4,
        "пять" to 5, "десять" to 10, "пятнадцать" to 15, "двадцать" to 20, "тридцать" to 30, "сорок пять" to 45)

    private fun timer(c: String): String {
        val n = Regex("\\d+").find(c)?.value?.toInt()
            ?: words.entries.firstOrNull { it.key in c }?.value
            ?: return "На сколько поставить таймер?"
        val (sec, unit) = when {
            "секунд" in c -> n to "сек."
            "час" in c -> n * 3600 to "ч."
            else -> n * 60 to "мин."
        }
        go(Intent(AlarmClock.ACTION_SET_TIMER)
            .putExtra(AlarmClock.EXTRA_LENGTH, sec)
            .putExtra(AlarmClock.EXTRA_MESSAGE, "JARVIS")
            .putExtra(AlarmClock.EXTRA_SKIP_UI, true))
        return "Таймер на $n $unit запущен."
    }

    private fun notes(): List<String> =
        (prefs.getString("notes", "") ?: "").split('\u0001').filter { it.isNotBlank() }

    private fun note(c: String): String {
        if ("покажи" in c || "прочитай" in c || "список" in c || "мои" in c) {
            val n = notes(); return if (n.isEmpty()) "Заметок пока нет." else "Ваши заметки: " + n.joinToString(". ")
        }
        if ("удали" in c || "очисти" in c) { prefs.edit().putString("notes", "").apply(); return "Все заметки удалены." }
        val t = Regex("заметк\\w*\\s*(.*)").find(c)?.groupValues?.get(1)?.trim().orEmpty()
        if (t.isEmpty()) return "Что записать в заметку?"
        prefs.edit().putString("notes", (notes() + t).joinToString("\u0001")).apply()
        return "Записал: $t"
    }

    private fun media(c: String): String {
        val am = app.getSystemService(AudioManager::class.java)
        val (code, reply) = when {
            "следующ" in c || "дальше" in c -> KeyEvent.KEYCODE_MEDIA_NEXT to "Следующий трек."
            "предыдущ" in c -> KeyEvent.KEYCODE_MEDIA_PREVIOUS to "Предыдущий трек."
            "пауз" in c || "стоп" in c || "останови" in c || "выключи" in c -> KeyEvent.KEYCODE_MEDIA_PAUSE to "Пауза."
            else -> KeyEvent.KEYCODE_MEDIA_PLAY to "Включаю музыку."
        }
        am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, code))
        am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_UP, code))
        return reply
    }

    private fun search(c: String): String {
        val q = c.replace(Regex("^(найди|поищи|загугли|поиск)( информацию)?( в интернете)?( про| о| об)?"), "").trim()
        if (q.isEmpty()) return "Что искать?"
        go(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q=" + Uri.encode(q))))
        return "Ищу: $q"
    }

    private fun site(c: String): String {
        val d = c.substringAfter("сайт").trim().replace(" ", "")
        if (d.isEmpty()) return "Какой сайт открыть?"
        val url = if ("." in d) (if (d.startsWith("http")) d else "https://$d") else "https://www.google.com/search?q=" + Uri.encode(d)
        go(Intent(Intent.ACTION_VIEW, Uri.parse(url))); return "Открываю $d"
    }

    // ---------- Приложения ----------
    fun installedApps(): List<AppInfo> {
        val pm = app.packageManager
        val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        return pm.queryIntentActivities(i, 0)
            .map { AppInfo(it.loadLabel(pm).toString(), it.activityInfo.packageName) }
            .distinctBy { it.pkg }.sortedBy { it.label.lowercase() }
    }

    fun launch(pkg: String): Boolean {
        val i = app.packageManager.getLaunchIntentForPackage(pkg) ?: return false
        go(i); return true
    }

    private val aliases = mapOf("ютуб" to "youtube", "телеграм" to "telegram", "телега" to "telegram",
        "ватсап" to "whatsapp", "вотсап" to "whatsapp", "хром" to "chrome", "инстаграм" to "instagram",
        "тикток" to "tiktok", "дискорд" to "discord", "вк" to "vk", "вконтакте" to "vk", "стим" to "steam",
        "карты" to "maps", "почта" to "gmail", "галерея" to "gallery", "калькулятор" to "calculator",
        "часы" to "clock", "контакты" to "contacts", "телефон" to "phone")

    private fun findApp(q: String): AppInfo? {
        val apps = installedApps()
        val key = aliases[q]
        return apps.firstOrNull { it.label.lowercase() == q }
            ?: apps.firstOrNull { it.label.lowercase().contains(q) }
            ?: key?.let { k -> apps.firstOrNull { it.label.lowercase().contains(k) || it.pkg.contains(k) } }
    }

    private fun openApp(c: String): String {
        val q = c.replace(Regex("^(открой|открыть|запусти|включи)\\s*(приложение)?"), "").trim()
        if (q.isEmpty()) return "Что открыть?"
        return openAppOrNull(q) ?: "Приложение «$q» не найдено."
    }

    private fun openAppOrNull(q: String): String? {
        val a = findApp(q.trim()) ?: return null
        return if (launch(a.pkg)) "Открываю ${a.label}." else null
    }
}
