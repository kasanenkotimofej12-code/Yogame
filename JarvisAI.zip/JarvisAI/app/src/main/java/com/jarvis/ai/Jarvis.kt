package com.jarvis.ai

import android.Manifest
import android.content.pm.PackageManager
import android.provider.ContactsContract
import androidx.core.content.ContextCompat
import android.content.Context
import android.content.Intent
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.Uri
import android.accessibilityservice.AccessibilityService
import android.os.BatteryManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.AlarmClock
import android.provider.MediaStore
import android.provider.Settings
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.Voice
import android.view.KeyEvent
import androidx.compose.runtime.*
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class AppInfo(val label: String, val pkg: String)

data class PendingSend(val who: String, val number: String, val text: String, val time: Long)

class Jarvis(private val app: Context) {
    private val prefs = app.getSharedPreferences("jarvis", Context.MODE_PRIVATE)
    private var tts: TextToSpeech? = null
    private var recognizer: SpeechRecognizer? = null
    private var torchOn = false

    var name by mutableStateOf(prefs.getString("name", "Джарвис") ?: "Джарвис")
    var status by mutableStateOf("Готов к работе")
    var level by mutableFloatStateOf(0f)
    var listening by mutableStateOf(false)
    val log = mutableStateListOf<String>()
    var favorites by mutableStateOf(prefs.getStringSet("fav", emptySet()) ?: emptySet())

    var ttsReady by mutableStateOf(false)
    var voiceName by mutableStateOf(prefs.getString("voice", "") ?: "")
    var pitch by mutableFloatStateOf(prefs.getFloat("pitch", 1f))
    var rate by mutableFloatStateOf(prefs.getFloat("rate", 1f))
    var pendingSend by mutableStateOf<PendingSend?>(null)
    var continuous by mutableStateOf(false)
    private val handler = Handler(Looper.getMainLooper())

    fun startContinuous() {
        continuous = true
        status = "Жду: «$name, команда»"
        startListening()
    }

    fun stopContinuous() {
        continuous = false
        handler.removeCallbacksAndMessages(null)
        recognizer?.destroy(); recognizer = null
        listening = false; level = 0f
        status = "Фоновый режим выключен"
    }

    private fun restart(delayMs: Long) {
        handler.postDelayed({ if (continuous) startListening() }, delayMs)
    }

    var permRequest by mutableStateOf<List<String>?>(null)
    private var pendingCmd: String? = null
    private var retrying = false

    init {
        tts = TextToSpeech(app) {
            if (it == TextToSpeech.SUCCESS) { tts?.language = Locale("ru", "RU"); applyVoice(); ttsReady = true }
        }
    }

    private fun applyVoice() {
        val t = tts ?: return
        t.setPitch(pitch); t.setSpeechRate(rate)
        if (voiceName.isNotEmpty()) try { t.voices?.firstOrNull { it.name == voiceName }?.let { t.voice = it } } catch (e: Exception) {}
    }

    fun russianVoices(): List<Voice> =
        try { tts?.voices?.filter { it.locale.language == "ru" }?.sortedBy { it.name } ?: emptyList() } catch (e: Exception) { emptyList() }

    fun chooseVoice(v: Voice) {
        voiceName = v.name; prefs.edit().putString("voice", v.name).apply()
        tts?.voice = v; preview()
    }
    fun changePitch(p: Float) { pitch = p; tts?.setPitch(p); prefs.edit().putFloat("pitch", p).apply() }
    fun changeRate(r: Float) { rate = r; tts?.setSpeechRate(r); prefs.edit().putFloat("rate", r).apply() }
    fun preview() { tts?.speak("Привет! Я $name. Так звучит мой голос.", TextToSpeech.QUEUE_FLUSH, null, "preview") }

    fun saveName(n: String) {
        if (n.isBlank()) return
        name = n.trim(); prefs.edit().putString("name", name).apply()
        say("Теперь меня зовут $name.")
    }

    fun toggleFavorite(pkg: String) {
        favorites = if (pkg in favorites) favorites - pkg else favorites + pkg
        prefs.edit().putStringSet("fav", favorites).apply()
    }

    // ---------- Голос ----------
    fun startListening() {
        if (!SpeechRecognizer.isRecognitionAvailable(app)) { status = "Распознавание речи недоступно"; return }
        recognizer?.destroy()
        recognizer = SpeechRecognizer.createSpeechRecognizer(app).apply {
            setRecognitionListener(object : RecognitionListener {
                override fun onReadyForSpeech(p: Bundle?) {}
                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(rms: Float) { level = ((rms + 2f) / 12f).coerceIn(0f, 1f) }
                override fun onBufferReceived(b: ByteArray?) {}
                override fun onEndOfSpeech() { listening = false; level = 0f }
                override fun onError(e: Int) {
                    listening = false; level = 0f
                    if (continuous) {
                        if (e == SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS) stopContinuous()
                        else restart(if (e == 7 || e == 6) 200L else 1000L)
                    } else status = "Не расслышал, попробуй ещё раз"
                }
                override fun onResults(r: Bundle?) {
                    listening = false; level = 0f
                    r?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()?.let { handle(it, voice = true) }
                    if (continuous) restart(300L)
                }
                override fun onPartialResults(r: Bundle?) {
                    if (!continuous) r?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()?.let { status = "«$it»" }
                }
                override fun onEvent(t: Int, p: Bundle?) {}
            })
            startListening(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
                .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                .putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ru-RU")
                .putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true))
        }
        listening = true; if (!continuous) status = "Слушаю…"
    }

    fun stopListening() { recognizer?.stopListening(); listening = false; level = 0f; status = "Микрофон выключен" }

    fun shutdown() { recognizer?.destroy(); tts?.shutdown() }

    fun say(text: String) {
        log.add("$name: $text"); status = text
        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "j")
    }

    // ---------- Команды ----------
    private val splitter = Regex("\\s+(?:и\\s+)?(?:потом|затем)\\s+|\\s+и\\s+(?=(?:открой|запусти|включи|выключи|позвони|поставь|найди|напиши|прибавь|убавь|сделай|покажи|зайди))")

    fun handle(raw: String, voice: Boolean = false) {
        val text = raw.trim(); if (text.isEmpty()) return
        var c = text.lowercase().replace("ё", "е")
        val n = name.lowercase().replace("ё", "е")
        pendingSend?.let { ps ->
            pendingSend = null
            val t = c.replace(n, "").trim(' ', ',', '.', '!', '?')
            if (System.currentTimeMillis() - ps.time < 20000) {
                if (t in setOf("да", "отправляй", "отправь", "отправить", "подтверждаю", "давай", "ага", "да отправляй")) {
                    log.add("Вы: $text"); say(doSend(ps)); return
                }
                if (t in setOf("нет", "отмена", "отмени", "не надо", "стоп", "не отправляй")) {
                    log.add("Вы: $text"); say("Отменил."); return
                }
            }
        }
        if (voice) {
            if (n !in c) {
                if (!continuous) {
                    log.add("Услышал: «$text» (без обращения, игнорирую)")
                    status = "Начни с имени: «$name, ...». Услышал: «$text»"
                }
                return
            }
        }
        log.add("Вы: $text")
        c = c.replace(n, "").trim(' ', ',', '.', '!', '?')
        val parts = c.split(splitter).map { it.trim(' ', ',', '.') }.filter { it.isNotEmpty() }
        val reply = (if (parts.isEmpty()) listOf("") else parts).joinToString(" ") { p ->
            try { execute(p) } catch (e: Exception) { "Не получилось: ${e.message}" }
        }
        say(reply)
    }

    fun retryPending() {
        val c = pendingCmd ?: return
        pendingCmd = null; retrying = true
        val reply = try { execute(c) } catch (e: Exception) { "Не получилось: ${e.message}" }
        retrying = false
        say(reply)
    }

    private fun granted(p: String) = ContextCompat.checkSelfPermission(app, p) == PackageManager.PERMISSION_GRANTED

    private fun call(c: String): String {
        val missing = listOf(Manifest.permission.READ_CONTACTS, Manifest.permission.CALL_PHONE).filter { !granted(it) }
        if (missing.isNotEmpty() && !retrying) {
            pendingCmd = c; permRequest = missing
            return "Мне нужен доступ к контактам и звонкам. Подтверди в окне."
        }
        val stop = setOf("контакту", "мне", "пожалуйста", "номеру", "на", "номер")
        val q = c.replace(Regex("^.*?(позвони|набери|звони)"), "").trim()
            .split(Regex("\\s+")).filter { it.isNotEmpty() && it !in stop }.joinToString(" ")
        if (q.isEmpty()) return "Кому позвонить?"
        val digits = q.replace(Regex("[\\s\\-()]"), "")
        val number: String; val who: String
        if (digits.matches(Regex("\\+?\\d{3,}"))) { number = digits; who = digits }
        else {
            if (!granted(Manifest.permission.READ_CONTACTS)) return "Нет доступа к контактам."
            val found = findContacts(q)
            if (found.isEmpty()) return "Контакт «$q» не найден."
            val names = found.map { it.first }.distinct()
            if (names.size > 1) return "Нашёл несколько: ${names.take(4).joinToString(", ")}. Уточни."
            number = found[0].second; who = found[0].first
        }
        val action = if (granted(Manifest.permission.CALL_PHONE)) Intent.ACTION_CALL else Intent.ACTION_DIAL
        go(Intent(action, Uri.parse("tel:" + Uri.encode(number))))
        return "Звоню: $who"
    }

    private fun prefix(a: String, b: String): Int { var i = 0; while (i < a.length && i < b.length && a[i] == b[i]) i++; return i }

    private fun findContacts(q: String): List<Pair<String, String>> {
        val qw = q.lowercase().replace("ё", "е").split(" ").filter { it.isNotEmpty() }
        val scored = mutableListOf<Triple<Int, String, String>>()
        app.contentResolver.query(ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
            arrayOf(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME, ContactsContract.CommonDataKinds.Phone.NUMBER),
            null, null, null)?.use { cur ->
            while (cur.moveToNext()) {
                val nm = cur.getString(0) ?: continue
                val num = cur.getString(1) ?: continue
                val words = nm.lowercase().replace("ё", "е").split(" ").filter { it.isNotEmpty() }
                var score = 0
                for (w in words) for (x in qw) {
                    val p = prefix(w, x)
                    if (p >= 3 || (p >= 2 && p == w.length)) score += p
                }
                if (score > 0) scored.add(Triple(score, nm, num))
            }
        }
        val best = scored.maxOfOrNull { it.first } ?: return emptyList()
        return scored.filter { it.first == best }.map { it.second to it.third }
    }

    private fun execute(c: String): String = when {
        c.isBlank() -> "Слушаю."
        "создай приложение" in c || "сделай приложение" in c || "создай игру" in c ->
            "Создание приложений в этой версии не поддерживается: здесь нет ИИ."
        "помощь" in c || "умеешь" in c ->
            "Умею: открыть любое приложение, вернуться домой или назад, позвонить, написать в WhatsApp или СМС, открыть чат с контактом, фонарик, таймер, будильник, громкость, маршрут, заметки, камера, настройки, музыка, поиск, ютуб, заряд батареи, время. Можно цепочкой: открой ютуб и включи фонарик."
        chatRe.containsMatchIn(c) && ("зайди" in c || c.startsWith("откр")) -> openChat(c)
        c.split(" ").size <= 4 && !c.contains("маршрут") && !c.startsWith("поехали") &&
            (c.startsWith("назад") || "нажми назад" in c || "вернись назад" in c) -> sysAction("back", c)
        c.split(" ").size <= 4 && !c.contains("маршрут") && !c.startsWith("поехали") &&
            ("домой" in c || "главный экран" in c || "рабочий стол" in c || "сверни" in c || "выйди" in c || "выйти" in c ||
                "выход" in c || c.startsWith("закрой")) -> sysAction("home", c)
        "последние приложения" in c || "недавние" in c || "переключи приложение" in c -> sysAction("recents", c)
        "уведомлени" in c && ("покажи" in c || "открой" in c) -> sysAction("notifications", c)
        "скриншот" in c || "снимок экрана" in c -> sysAction("screenshot", c)
        "позвони" in c || "набери" in c || c.startsWith("звони") -> call(c)
        "фонар" in c -> torch(!("выключ" in c || "погас" in c || "отключ" in c))
        "таймер" in c -> timer(c)
        "заметк" in c -> note(c)
        "громкост" in c || "громче" in c || "тише" in c || "без звука" in c || "выключи звук" in c || "включи звук" in c -> volume(c)
        "будильник" in c -> alarm(c)
        c.startsWith("напиши") || c.startsWith("отправь") || "смс" in c -> sms(c)
        "маршрут" in c || "навигаци" in c || c.startsWith("проложи") || c.startsWith("поехали") -> navigate(c)
        "заряд" in c || "батаре" in c -> battery()
        ("ютуб" in c || "youtube" in c) && ("найди" in c || "поищи" in c) -> youtubeSearch(c)
        "камер" in c || "сфотографируй" in c -> { go(Intent(MediaStore.ACTION_IMAGE_CAPTURE)); "Открываю камеру." }
        "музык" in c || "пауз" in c || "следующ" in c || "предыдущ" in c || "дальше" in c -> media(c)
        "wi-fi" in c || "вай" in c -> { go(Intent(Settings.ACTION_WIFI_SETTINGS)); "Открываю настройки Wi-Fi." }
        "bluetooth" in c || "блютуз" in c -> { go(Intent(Settings.ACTION_BLUETOOTH_SETTINGS)); "Открываю Bluetooth." }
        "настройк" in c -> { go(Intent(Settings.ACTION_SETTINGS)); "Открываю настройки." }
        "котор" in c && "час" in c || "сколько времени" in c || "время" in c ->
            "Сейчас " + SimpleDateFormat("HH:mm", Locale("ru")).format(Date())
        "какое число" in c || "дата" in c || "какой день" in c ->
            "Сегодня " + SimpleDateFormat("d MMMM, EEEE", Locale("ru")).format(Date())
        c.startsWith("найди") || c.startsWith("поищи") || c.startsWith("загугли") || c.startsWith("поиск") -> search(c)
        "сайт" in c -> site(c)
        c.startsWith("откр") || c.startsWith("отрой") || c.startsWith("запусти") || c.startsWith("включи") || c.startsWith("зайди") -> openApp(c)
        else -> openAppOrNull(c) ?: "Не понял команду. Скажи «помощь», чтобы узнать, что я умею."
    }

    private fun go(i: Intent) { app.startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }

    private fun torch(on: Boolean): String {
        val cm = app.getSystemService(CameraManager::class.java)
        val id = cm.cameraIdList.firstOrNull {
            cm.getCameraCharacteristics(it).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
        } ?: return "Фонарик на этом устройстве не найден."
        cm.setTorchMode(id, on); torchOn = on
        return if (on) "Фонарик включён." else "Фонарик выключен."
    }

    private val words = mapOf("одну" to 1, "одна" to 1, "две" to 2, "два" to 2, "три" to 3, "четыре" to 4,
        "пять" to 5, "десять" to 10, "пятнадцать" to 15, "двадцать" to 20, "тридцать" to 30, "сорок пять" to 45)

    private fun timer(c: String): String {
        val n = Regex("\\d+").find(c)?.value?.toInt()
            ?: words.entries.firstOrNull { it.key in c }?.value
            ?: return "На сколько поставить таймер?"
        val (sec, unit) = when {
            "секунд" in c -> n to "сек."
            "час" in c -> n * 3600 to "ч."
            else -> n * 60 to "мин."
        }
        go(Intent(AlarmClock.ACTION_SET_TIMER)
            .putExtra(AlarmClock.EXTRA_LENGTH, sec)
            .putExtra(AlarmClock.EXTRA_MESSAGE, "JARVIS")
            .putExtra(AlarmClock.EXTRA_SKIP_UI, true))
        return "Таймер на $n $unit запущен."
    }

    private fun notes(): List<String> =
        (prefs.getString("notes", "") ?: "").split('\u0001').filter { it.isNotBlank() }

    private fun note(c: String): String {
        if ("покажи" in c || "прочитай" in c || "список" in c || "мои" in c) {
            val n = notes(); return if (n.isEmpty()) "Заметок пока нет." else "Ваши заметки: " + n.joinToString(". ")
        }
        if ("удали" in c || "очисти" in c) { prefs.edit().putString("notes", "").apply(); return "Все заметки удалены." }
        val t = Regex("заметк[а-яё]*\\s*(.*)").find(c)?.groupValues?.get(1)?.trim().orEmpty()
        if (t.isEmpty()) return "Что записать в заметку?"
        prefs.edit().putString("notes", (notes() + t).joinToString("\u0001")).apply()
        return "Записал: $t"
    }

    private fun sysAction(what: String, c: String): String {
        val svc = JarvisAccessibilityService.instance
        if (what == "home") {
            if (svc != null) svc.performGlobalAction(AccessibilityService.GLOBAL_ACTION_HOME)
            else go(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME))
            return if (c.startsWith("закрой")) "Закрыть чужое приложение Android не позволяет, возвращаюсь на главный экран."
            else "Возвращаюсь на главный экран."
        }
        if (svc == null) {
            go(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            return "Для этой команды включи «JARVIS AI» в специальных возможностях, потом повтори."
        }
        return when (what) {
            "back" -> { svc.performGlobalAction(AccessibilityService.GLOBAL_ACTION_BACK); "Назад." }
            "recents" -> { svc.performGlobalAction(AccessibilityService.GLOBAL_ACTION_RECENTS); "Открываю последние приложения." }
            "notifications" -> { svc.performGlobalAction(AccessibilityService.GLOBAL_ACTION_NOTIFICATIONS); "Открываю уведомления." }
            else -> if (Build.VERSION.SDK_INT >= 28) {
                svc.performGlobalAction(AccessibilityService.GLOBAL_ACTION_TAKE_SCREENSHOT); "Делаю скриншот."
            } else "Скриншот по команде работает на Android 9 и новее."
        }
    }

    private fun volume(c: String): String {
        val am = app.getSystemService(AudioManager::class.java)
        val st = AudioManager.STREAM_MUSIC
        val max = am.getStreamMaxVolume(st)
        val num = Regex("\\d+").find(c)?.value?.toInt()
        return when {
            "включи звук" in c -> { am.adjustStreamVolume(st, AudioManager.ADJUST_UNMUTE, AudioManager.FLAG_SHOW_UI); "Звук включён." }
            "без звука" in c || "выключи звук" in c -> { am.adjustStreamVolume(st, AudioManager.ADJUST_MUTE, AudioManager.FLAG_SHOW_UI); "Звук выключен." }
            "максимум" in c || "полную" in c -> { am.setStreamVolume(st, max, AudioManager.FLAG_SHOW_UI); "Громкость на максимум." }
            num != null -> { am.setStreamVolume(st, max * num.coerceIn(0, 100) / 100, AudioManager.FLAG_SHOW_UI); "Громкость $num процентов." }
            "тише" in c || "убав" in c || "меньше" in c || "ниже" in c -> {
                repeat(3) { am.adjustStreamVolume(st, AudioManager.ADJUST_LOWER, if (it == 2) AudioManager.FLAG_SHOW_UI else 0) }; "Тише."
            }
            else -> { repeat(3) { am.adjustStreamVolume(st, AudioManager.ADJUST_RAISE, if (it == 2) AudioManager.FLAG_SHOW_UI else 0) }; "Громче." }
        }
    }

    private fun alarm(c: String): String {
        val m = Regex("(\\d{1,2})(?:[:.\\s](\\d{2}))?").find(c) ?: return "На какое время поставить будильник?"
        var h = m.groupValues[1].toInt(); val min = m.groupValues[2].ifEmpty { "0" }.toInt()
        if ("вечера" in c && h < 12) h += 12
        if ("дня" in c && h in 1..6) h += 12
        if (h > 23 || min > 59) return "Не понял время."
        go(Intent(AlarmClock.ACTION_SET_ALARM).putExtra(AlarmClock.EXTRA_HOUR, h).putExtra(AlarmClock.EXTRA_MINUTES, min)
            .putExtra(AlarmClock.EXTRA_MESSAGE, "JARVIS").putExtra(AlarmClock.EXTRA_SKIP_UI, true))
        return "Будильник на %d:%02d поставлен.".format(h, min)
    }

    private val chatRe = Regex("(чат[а-яё]*|переписк[а-яё]*|диалог[а-яё]*)\\s+(с|со)\\s+")

    private fun needContacts(c: String): String? {
        if (granted(Manifest.permission.READ_CONTACTS)) return null
        if (!retrying) { pendingCmd = c; permRequest = listOf(Manifest.permission.READ_CONTACTS); return "Мне нужен доступ к контактам. Подтверди в окне." }
        return "Нет доступа к контактам."
    }

    private fun waInstalled() = listOf("com.whatsapp", "com.whatsapp.w4b").any { app.packageManager.getLaunchIntentForPackage(it) != null }

    private fun waDigits(raw: String): String {
        var d = raw.filter { it.isDigit() }
        if (d.length == 11 && d.startsWith("8")) d = "7" + d.drop(1)
        else if (d.length == 10) d = "7$d"
        return d
    }

    private fun openWa(number: String, text: String?) {
        val q = if (text != null) "&text=" + Uri.encode(text) else ""
        for (pkg in listOf("com.whatsapp", "com.whatsapp.w4b")) {
            if (app.packageManager.getLaunchIntentForPackage(pkg) != null) {
                go(Intent(Intent.ACTION_VIEW, Uri.parse("whatsapp://send?phone=$number$q")).setPackage(pkg)); return
            }
        }
        go(Intent(Intent.ACTION_VIEW, Uri.parse("https://wa.me/$number" + (if (text != null) "?text=" + Uri.encode(text) else ""))))
    }

    private fun pickContact(q: String): Pair<Pair<String, String>?, String?> {
        val found = findContacts(q)
        if (found.isEmpty()) return null to "Контакт «$q» не найден."
        val names = found.map { it.first }.distinct()
        if (names.size > 1) return null to "Нашёл несколько: ${names.take(4).joinToString(", ")}. Уточни."
        return found[0] to null
    }

    private fun openChat(c: String): String {
        needContacts(c)?.let { return it }
        val q = Regex("(?:чат[а-яё]*|переписк[а-яё]*|диалог[а-яё]*)\\s+(?:с\\s+|со\\s+)(.+)$").find(c)?.groupValues?.get(1)?.trim().orEmpty()
        if (q.isEmpty()) return "С кем открыть чат?"
        val (hit, err) = pickContact(q)
        if (hit == null) return err ?: "Контакт не найден."
        openWa(waDigits(hit.second), null)
        return "Открываю чат с ${hit.first}."
    }

    private fun sms(c0: String): String {
        needContacts(c0)?.let { return it }
        val viaSms = "смс" in c0
        val c = c0.replace(Regex("\\s*(?:в|через|по)\\s+(?:ватсап[а-яё]*|вацап[а-яё]*|вотсап[а-яё]*|whatsapp|смс)"), " ")
        val rest = c.replace(Regex("^.*?(напиши|отправь|смс|сообщение)\\s*(сообщение|смс)?\\s*(контакту)?\\s*"), "").trim()
        val first = rest.substringBefore(" "); val body = rest.substringAfter(" ", "").trim()
        if (first.isEmpty()) return "Кому написать?"
        val (hit, err) = pickContact(first)
        if (hit == null) return err ?: "Контакт не найден."
        val who = hit.first; val num = hit.second
        if (viaSms || !waInstalled()) {
            go(Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:" + Uri.encode(num))).putExtra("sms_body", body))
            return "Открываю сообщение для $who. Осталось нажать «Отправить»."
        }
        if (body.isEmpty()) return "Что написать для $who?"
        val text = body.replaceFirstChar { it.uppercase() }
        val ps = PendingSend(who, waDigits(num), text, System.currentTimeMillis())
        pendingSend = ps
        handler.postDelayed({ if (pendingSend === ps) pendingSend = null }, 20000)
        return "Написать $who в WhatsApp: «$text». Отправить? Скажи «да» или «нет»."
    }

    fun confirmSend() { val ps = pendingSend ?: return; pendingSend = null; say(doSend(ps)) }
    fun cancelSend() { pendingSend = null; say("Отменил.") }

    private fun doSend(ps: PendingSend): String {
        openWa(ps.number, ps.text)
        val svc = JarvisAccessibilityService.instance
            ?: return "Чат с ${ps.who} открыт, текст вставлен. Чтобы я нажимал «Отправить» сам, включи JARVIS AI в специальных возможностях."
        svc.clickSendWhatsApp { ok -> say(if (ok) "Отправил ${ps.who}: ${ps.text}" else "Не нашёл кнопку отправки, нажми её сам.") }
        return "Отправляю сообщение для ${ps.who}…"
    }

    private fun navigate(c: String): String {
        val q = c.replace(Regex("^.*?(маршрут|навигаци[а-яё]*|проложи|поехали)\\s*(маршрут)?\\s*(до|в|к|на)?\\s*"), "").trim()
        if (q.isEmpty()) return "Куда ехать?"
        try { go(Intent(Intent.ACTION_VIEW, Uri.parse("google.navigation:q=" + Uri.encode(q))).setPackage("com.google.android.apps.maps")) }
        catch (e: Exception) { go(Intent(Intent.ACTION_VIEW, Uri.parse("geo:0,0?q=" + Uri.encode(q)))) }
        return "Строю маршрут: $q"
    }

    private fun battery(): String {
        val bm = app.getSystemService(BatteryManager::class.java)
        return "Заряд батареи ${bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)} процентов."
    }

    private fun youtubeSearch(c: String): String {
        val q = c.replace(Regex("^.*?(найди|поищи)\\s*"), "")
            .replace(Regex("^(на |в )?(ютубе|ютуб|youtube)\\s*"), "")
            .replace(Regex("\\s+(на|в)\\s+(ютубе|ютуб|youtube)$"), "").trim()
        if (q.isEmpty()) return "Что искать на ютубе?"
        go(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com/results?search_query=" + Uri.encode(q))))
        return "Ищу на ютубе: $q"
    }

    private fun media(c: String): String {
        val am = app.getSystemService(AudioManager::class.java)
        val (code, reply) = when {
            "следующ" in c || "дальше" in c -> KeyEvent.KEYCODE_MEDIA_NEXT to "Следующий трек."
            "предыдущ" in c -> KeyEvent.KEYCODE_MEDIA_PREVIOUS to "Предыдущий трек."
            "пауз" in c || "стоп" in c || "останови" in c || "выключи" in c -> KeyEvent.KEYCODE_MEDIA_PAUSE to "Пауза."
            else -> KeyEvent.KEYCODE_MEDIA_PLAY to "Включаю музыку."
        }
        am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, code))
        am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_UP, code))
        return reply
    }

    private fun search(c: String): String {
        val q = c.replace(Regex("^(найди|поищи|загугли|поиск)( информацию)?( в интернете)?( про| о| об)?"), "").trim()
        if (q.isEmpty()) return "Что искать?"
        go(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q=" + Uri.encode(q))))
        return "Ищу: $q"
    }

    private fun site(c: String): String {
        val d = c.substringAfter("сайт").trim().replace(" ", "")
        if (d.isEmpty()) return "Какой сайт открыть?"
        val url = if ("." in d) (if (d.startsWith("http")) d else "https://$d") else "https://www.google.com/search?q=" + Uri.encode(d)
        go(Intent(Intent.ACTION_VIEW, Uri.parse(url))); return "Открываю $d"
    }

    // ---------- Приложения ----------
    fun installedApps(): List<AppInfo> {
        val pm = app.packageManager
        val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        return pm.queryIntentActivities(i, 0)
            .map { AppInfo(it.loadLabel(pm).toString(), it.activityInfo.packageName) }
            .distinctBy { it.pkg }.sortedBy { it.label.lowercase() }
    }

    fun launch(pkg: String): Boolean {
        val i = app.packageManager.getLaunchIntentForPackage(pkg) ?: return false
        go(i); return true
    }

    private val aliases = mapOf("ютуб" to "youtube", "телеграм" to "telegram", "телега" to "telegram",
        "ватсап" to "whatsapp", "вацап" to "whatsapp", "ватсапп" to "whatsapp", "вотсапп" to "whatsapp", "вотсап" to "whatsapp", "хром" to "chrome", "инстаграм" to "instagram",
        "тикток" to "tiktok", "дискорд" to "discord", "вк" to "vk", "вконтакте" to "vk", "стим" to "steam",
        "карты" to "maps", "почта" to "gmail", "галерея" to "gallery", "калькулятор" to "calculator",
        "часы" to "clock", "контакты" to "contacts", "телефон" to "phone")

    private val tr = mapOf('а' to "a", 'б' to "b", 'в' to "v", 'г' to "g", 'д' to "d", 'е' to "e", 'ё' to "e",
        'ж' to "zh", 'з' to "z", 'и' to "i", 'й' to "i", 'к' to "k", 'л' to "l", 'м' to "m", 'н' to "n", 'о' to "o",
        'п' to "p", 'р' to "r", 'с' to "s", 'т' to "t", 'у' to "u", 'ф' to "f", 'х' to "h", 'ц' to "ts", 'ч' to "ch",
        'ш' to "sh", 'щ' to "sh", 'ъ' to "", 'ы' to "i", 'ь' to "", 'э' to "e", 'ю' to "iu", 'я' to "ia")

    // Приводит русское и английское название к одному "звучанию": "тик ток" и "TikTok" дают tiktok
    private fun key(s: String): String {
        val sb = StringBuilder()
        for (ch in s.lowercase()) sb.append(tr[ch] ?: ch.toString())
        var k = sb.toString()
        k = k.replace("dzh", "g").replace("zh", "g").replace("dj", "g").replace("j", "g")
            .replace("ph", "f").replace("ck", "k").replace("c", "k")
            .replace("w", "v").replace("y", "i").replace("x", "ks")
        k = k.replace(Regex("[^a-z0-9]"), "")
        return k.replace(Regex("(.)\\1+"), "$1")
    }

    private fun lev(a: String, b: String): Int {
        val dp = IntArray(b.length + 1) { it }
        for (i in 1..a.length) {
            var prev = dp[0]; dp[0] = i
            for (j in 1..b.length) {
                val tmp = dp[j]
                dp[j] = minOf(dp[j] + 1, dp[j - 1] + 1, prev + if (a[i - 1] == b[j - 1]) 0 else 1)
                prev = tmp
            }
        }
        return dp[b.length]
    }

    private fun findApp(q0: String): AppInfo? {
        val q = q0.trim().lowercase().replace("ё", "е")
        val qks = listOfNotNull(key(q), aliases[q]?.let { key(it) }).filter { it.length >= 2 }
        if (qks.isEmpty()) return null
        var best: AppInfo? = null; var bestScore = Int.MAX_VALUE
        for (a in installedApps()) {
            val lk = key(a.label); if (lk.isEmpty()) continue
            for (qk in qks) {
                val score = when {
                    lk == qk -> 0
                    lk.length >= 3 && (lk.startsWith(qk) || qk.startsWith(lk)) -> 1 + Math.abs(lk.length - qk.length)
                    lk.length >= 3 && qk.length >= 3 && (lk.contains(qk) || qk.contains(lk)) -> 3 + Math.abs(lk.length - qk.length)
                    else -> { val d = lev(lk, qk); if (d <= maxOf(1, minOf(lk.length, qk.length) / 4)) 10 + d else Int.MAX_VALUE }
                }
                if (score < bestScore) { bestScore = score; best = a }
            }
        }
        return best
    }

    private fun openApp(c: String): String {
        val q = c.replace(Regex("^(откр[а-яё]*|отрой|запусти[а-яё]*|включи|зайди\\s+(?:в|на))\\s*(приложение)?\\s*"), "").trim()
        if (q.isEmpty()) return "Что открыть?"
        return openAppOrNull(q) ?: "Приложение «$q» не найдено."
    }

    private fun openAppOrNull(q: String): String? {
        val a = findApp(q.trim()) ?: return null
        return if (launch(a.pkg)) "Открываю ${a.label}." else null
    }
}

object JarvisHolder {
    private var inst: Jarvis? = null
    fun get(c: Context): Jarvis = inst ?: Jarvis(c.applicationContext).also { inst = it }
}
